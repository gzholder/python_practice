"""
All the customer order stuff! 📋
Takes care of who wants what and how much it costs.
"""

from . import colors


class OrderManager:
    def __init__(self, customer_name, pizza_size, toppings, drink, phone):
        self.customer_name = customer_name
        self.pizza_size = pizza_size
        self.toppings = toppings
        self.drink = drink
        self.phone = phone
        
        self.base_price = 25.00
        self.topping_price = 0
        self.drink_price = 2.99
        self.total = self.base_price + self.drink_price

    def display_welcome(self):
        print(f"{colors.BLUE}=== Welcome to Gabriel's Pizza! ==={colors.RESET}")

    def display_order_details(self):
        print(f"Customer: {colors.YELLOW}{self.customer_name}{colors.RESET}")
        print(f"Pizza Size: {colors.YELLOW}{self.pizza_size}{colors.RESET}")
        print(f"Toppings: {colors.YELLOW}{', '.join(self.toppings)}{colors.RESET}")
        print(f"Drink: {colors.YELLOW}{self.drink}{colors.RESET}")
        print(f"Phone: {colors.YELLOW}{self.phone}{colors.RESET}")
        print(f"\nTotal: {colors.GREEN}${self.total:.2f}{colors.RESET}")

    def confirm_order(self):
        confirm = input(f"\n{colors.YELLOW}Confirm order? Y/N: {colors.RESET}").upper()
        if confirm != "Y":
            print(f"{colors.RED}Order cancelled{colors.RESET}")
            exit()

    def calculate_loyalty_points(self):
        points = int(self.total)
        print(f"\n{colors.YELLOW}Let's see what Frank earned today...{colors.RESET}")
        print(f"  → Order came to: ${self.total:.2f}")
        print(f"  → Points earned: {points}")
        print(f"{colors.GREEN}Points are in the bank for {self.customer_name}!{colors.RESET}")

    def print_receipt(self):
        print(f"\n{colors.BLUE}{'='*40}")
        print(f"           Gabriel'S PIZZA RECEIPT")
        print(f"{'='*40}")
        print(f"Customer: {self.customer_name}")
        print(f"Phone: {self.phone}")
        print(f"")
        print(f"{self.pizza_size} Pizza        ${self.base_price:.2f}")
        for topping in self.toppings:
            print(f"  + {topping}")
        print(f"{self.drink}                 ${self.drink_price:.2f}")
        print(f"{'='*40}")
        print(f"TOTAL:                ${self.total:.2f}")
        print(f"{'='*40}{colors.RESET}")