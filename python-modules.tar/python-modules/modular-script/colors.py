"""
Pretty colors for the terminal! 🌈
Because plain white text is boring.
"""

GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
RESET = '\033[0m'