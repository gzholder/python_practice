"""
Gabriel's Pizza Order System - Now with Organization! 📦

Shows how to take one big messy script and break it into 
nice, clean modules that don't make your eyes bleed.
"""