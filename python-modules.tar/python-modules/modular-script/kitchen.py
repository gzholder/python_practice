"""
Where the pizza magic happens! 🍕👨‍🍳
All the cooking, prep, and packaging stuff.
"""

import time
from . import colors


class Kitchen:
    def __init__(self, toppings, drink):
        self.toppings = toppings
        self.drink = drink

    def validate_ingredients(self):
        print(f"\n{colors.YELLOW}Checking what we've got in the kitchen...{colors.RESET}")
        time.sleep(1)
        
        ingredients = ["flour", "cheese", "sauce"] + self.toppings
        for ingredient in ingredients:
            print(f"  ✓ {ingredient}: We're good")
        
        print(f"{colors.GREEN}Sweet! We've got everything we need{colors.RESET}")

    def prepare_dough(self):
        print(f"\n{colors.YELLOW}Alright, let's make some dough...{colors.RESET}")
        time.sleep(2)
        print("  → Throwing flour and water together")
        print("  → Getting my hands dirty with the kneading")
        print("  → Rolling this bad boy out")
        print(f"{colors.GREEN}Dough is looking good!{colors.RESET}")

    def add_sauce_and_cheese(self):
        print(f"\n{colors.YELLOW}Time for the good stuff...{colors.RESET}")
        time.sleep(1)
        print("  → Slathering on that red sauce")
        print("  → Piling on the mozzarella")
        print(f"{colors.GREEN}Base is looking delicious!{colors.RESET}")

    def add_toppings(self):
        print(f"\n{colors.YELLOW}Now for the fun part - toppings!{colors.RESET}")
        for topping in self.toppings:
            print(f"  → Tossing on some {topping}")
            time.sleep(0.5)
        print(f"{colors.GREEN}Toppings are looking perfect!{colors.RESET}")

    def bake_pizza(self):
        print(f"\n{colors.YELLOW}Into the oven at 800°F - this is gonna be good!{colors.RESET}")
        bake_time = 12
        for minute in range(1, bake_time + 1):
            print(f"  Cooking away... {minute}/{bake_time} minutes")
            time.sleep(0.3)
        print(f"{colors.GREEN}That's one beautiful pizza!{colors.RESET}")

    def prepare_drink(self):
        print(f"\n{colors.YELLOW}Grab a cold one...{colors.RESET}")
        time.sleep(1)
        print(f"  → Snagging a {self.drink} from the fridge")
        print(f"  → Throwing in some ice")
        print(f"{colors.GREEN}Drink is nice and cold!{colors.RESET}")

    def package_order(self):
        print(f"\n{colors.YELLOW}Let's get this order ready to go...{colors.RESET}")
        time.sleep(1)
        print("  → Slicing this beauty into 8 perfect pieces")
        print("  → Boxing it up nice and tight")
        print(f"  → Tossing the {self.drink} in the bag")
        print("  → Throwing in some napkins and plates")
        print(f"{colors.GREEN}All packed up and ready!{colors.RESET}")