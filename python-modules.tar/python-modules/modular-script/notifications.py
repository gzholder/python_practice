"""
Sending texts to hungry customers! 📱
Let 'em know their pizza is ready.
"""

import time
from . import colors


class NotificationService:
    def __init__(self, customer_name):
        self.customer_name = customer_name

    def send_notification(self):
        print(f"\n{colors.YELLOW}Time to let Frank know his pizza is ready...{colors.RESET}")
        time.sleep(1)
        print(f"📱 Text sent: 'Hey {self.customer_name}! Your pizza is hot and ready!'")
        print(f"{colors.GREEN}Frank's been notified!{colors.RESET}")