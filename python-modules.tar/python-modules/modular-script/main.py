"""
The main show! 🎬
This is where everything comes together and runs.

Shows how to break up a big script:
- order_manager.py: customer/pricing stuff
- kitchen.py: pizza making magic
- notifications.py: texting customers  
- colors.py: pretty terminal colors
"""

from .order_manager import OrderManager
from .kitchen import Kitchen
from .notifications import NotificationService
from . import colors


class PizzaOrderSystem:
    def __init__(self, customer_name, pizza_size, toppings, drink, phone):
        self.order_manager = OrderManager(customer_name, pizza_size, toppings, drink, phone)
        self.kitchen = Kitchen(toppings, drink)
        self.notification_service = NotificationService(customer_name)

    def process_order(self):
        self.order_manager.display_welcome()
        self.order_manager.display_order_details()
        self.order_manager.confirm_order()

    def make_pizza(self):
        print(f"\n{colors.GREEN}🍕 Let's make Frank's pizza! 🍕{colors.RESET}")
        
        self.kitchen.validate_ingredients()
        self.kitchen.prepare_dough()
        self.kitchen.add_sauce_and_cheese()
        self.kitchen.add_toppings()
        self.kitchen.bake_pizza()
        self.kitchen.prepare_drink()
        self.kitchen.package_order()
        self.notification_service.send_notification()
        self.order_manager.calculate_loyalty_points()
        self.order_manager.print_receipt()
        
        print(f"\n{colors.GREEN}🎉 All done! Frank's gonna love this pizza! 🎉{colors.RESET}")

    def run(self):
        self.process_order()
        self.make_pizza()


if __name__ == "__main__":
    # Define customer order data in main
    customer_name = "Frank"
    pizza_size = "Large"
    toppings = ["pepperoni", "onion"]
    drink = "Coke"
    phone = "123-456-7899"
    
    # Create and run the pizza order system
    pizza_system = PizzaOrderSystem(customer_name, pizza_size, toppings, drink, phone)
    pizza_system.run()