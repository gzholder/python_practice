import time

class PizzaOrder:
    def __init__(self):
        # Colors to make this look fancy! 🌈
        self.GREEN = '\033[92m'
        self.RED = '\033[91m'
        self.YELLOW = '\033[93m'
        self.BLUE = '\033[94m'
        self.RESET = '\033[0m'
        
        # Show the welcome message 👋
        print(f"{self.BLUE}=== Welcome to Gabriel's Pizza! ==={self.RESET}")
        
        # Pretend Frank called in an order 📞
        self.customer_name = "Frank"
        self.pizza_size = "Large"
        self.toppings = ["pepperoni", "onion"]
        self.drink = "Coke"
        self.phone = "123-456-7899"
        
        print(f"Customer: {self.YELLOW}{self.customer_name}{self.RESET}")
        print(f"Pizza Size: {self.YELLOW}{self.pizza_size}{self.RESET}")
        print(f"Toppings: {self.YELLOW}{', '.join(self.toppings)}{self.RESET}")
        print(f"Drink: {self.YELLOW}{self.drink}{self.RESET}")
        print(f"Phone: {self.YELLOW}{self.phone}{self.RESET}")
        
        # Time to figure out what this costs 💰
        self.base_price = 25.00
        self.topping_price = 0  # Toppings included in base price
        self.drink_price = 2.99 # Drink as separate item
        self.total = self.base_price + self.drink_price
        
        print(f"\nTotal: {self.GREEN}${self.total:.2f}{self.RESET}")
        
        confirm = input(f"\n{self.YELLOW}Confirm order? Y/N: {self.RESET}").upper()
        if confirm != "Y":
            print(f"{self.RED}Order cancelled{self.RESET}")
            exit()

    def validate_ingredients(self):
        print(f"\n{self.YELLOW}Checking what we've got in the kitchen...{self.RESET}")
        time.sleep(1)
        
        ingredients = ["flour", "cheese", "sauce"] + self.toppings
        for ingredient in ingredients:
            print(f"  ✓ {ingredient}: We're good")
        
        print(f"{self.GREEN}Sweet! We've got everything we need{self.RESET}")

    def prepare_dough(self):
        print(f"\n{self.YELLOW}Alright, let's make some dough...{self.RESET}")
        time.sleep(2)
        print("  → Throwing flour and water together")
        print("  → Getting my hands dirty with the kneading")
        print("  → Rolling this bad boy out")
        print(f"{self.GREEN}Dough is looking good!{self.RESET}")

    def add_sauce_and_cheese(self):
        print(f"\n{self.YELLOW}Time for the good stuff...{self.RESET}")
        time.sleep(1)
        print("  → Slathering on that red sauce")
        print("  → Piling on the mozzarella")
        print(f"{self.GREEN}Base is looking delicious!{self.RESET}")

    def add_toppings(self):
        print(f"\n{self.YELLOW}Now for the fun part - toppings!{self.RESET}")
        for topping in self.toppings:
            print(f"  → Tossing on some {topping}")
            time.sleep(0.5)
        print(f"{self.GREEN}Toppings are looking perfect!{self.RESET}")

    def bake_pizza(self):
        print(f"\n{self.YELLOW}Into the oven at 800°F - this is gonna be good!{self.RESET}")
        bake_time = 12
        for minute in range(1, bake_time + 1):
            print(f"  Cooking away... {minute}/{bake_time} minutes")
            time.sleep(0.3)
        print(f"{self.GREEN}That's one beautiful pizza!{self.RESET}")

    def prepare_drink(self):
        print(f"\n{self.YELLOW}Grab a cold one...{self.RESET}")
        time.sleep(1)
        print(f"  → Snagging a {self.drink} from the fridge")
        print(f"  → Throwing in some ice")
        print(f"{self.GREEN}Drink is nice and cold!{self.RESET}")

    def package_order(self):
        print(f"\n{self.YELLOW}Let's get this order ready to go...{self.RESET}")
        time.sleep(1)
        print("  → Slicing this beauty into 8 perfect pieces")
        print("  → Boxing it up nice and tight")
        print(f"  → Tossing the {self.drink} in the bag")
        print("  → Throwing in some napkins and plates")
        print(f"{self.GREEN}All packed up and ready!{self.RESET}")

    def send_notification(self):
        print(f"\n{self.YELLOW}Time to let Frank know his pizza is ready...{self.RESET}")
        time.sleep(1)
        print(f"📱 Text sent: 'Hey {self.customer_name}! Your pizza is hot and ready!'")
        print(f"{self.GREEN}Frank's been notified!{self.RESET}")

    def calculate_loyalty_points(self):
        points = int(self.total)  # 1 point per dollar
        print(f"\n{self.YELLOW}Let's see what Frank earned today...{self.RESET}")
        print(f"  → Order came to: ${self.total:.2f}")
        print(f"  → Points earned: {points}")
        print(f"{self.GREEN}Points are in the bank for {self.customer_name}!{self.RESET}")

    def print_receipt(self):
        print(f"\n{self.BLUE}{'='*40}")
        print(f"           Gabriel'S PIZZA RECEIPT")
        print(f"{'='*40}")
        print(f"Customer: {self.customer_name}")
        print(f"Phone: {self.phone}")
        print(f"")
        print(f"{self.pizza_size} Pizza        ${self.base_price:.2f}")
        for topping in self.toppings:
            print(f"  + {topping}")
        print(f"{self.drink}                 ${self.drink_price:.2f}")
        print(f"{'='*40}")
        print(f"TOTAL:                ${self.total:.2f}")
        print(f"{'='*40}{self.RESET}")

    def make_pizza(self):
        print(f"\n{self.GREEN}🍕 Let's make Frank's pizza! 🍕{self.RESET}")
        
        self.validate_ingredients()
        self.prepare_dough()
        self.add_sauce_and_cheese() 
        self.add_toppings()
        self.bake_pizza()
        self.prepare_drink()
        self.package_order()
        self.send_notification()
        self.calculate_loyalty_points()
        self.print_receipt()
        
        print(f"\n{self.GREEN}🎉 All done! Frank's gonna love this pizza! 🎉{self.RESET}")

# Run the pizza order
if __name__ == "__main__":
    order = PizzaOrder()
    order.make_pizza()