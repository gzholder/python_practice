# Breaking Up Large Python Scripts 🐍

## How to Run

**Big messy script:**
```bash
python basic-script/pizza_order.py
```

**Clean organized version:**
```bash
python -m modular-script.main
```
*The `-m` tells Python to run a module as a script*

## Your Questions Answered

**Do I create an init file?** → Yes! Need `__init__.py` to make it a package

**And a main.py that imports each module?** → Exactly! 

I broke it into:
- `colors.py` - color codes
- `order_manager.py` - customer/pricing stuff  
- `kitchen.py` - pizza making
- `notifications.py` - texting customers
- `main.py` - runs everything

**💅 Why bother?**
- Fix kitchen code? Only touch kitchen.py
- Each file = one job
- Test pieces separately
- No more endless scrolling

Both work exactly the same!
